import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { HomeComponent } from './components/layout/home/home.component';
import { ResetPwdComponent } from './auth/reset-pwd/reset-pwd.component';
import { SubmitPwdComponent } from './auth/submit-pwd/submit-pwd.component';
import { DefaultComponent } from './layouts/default/default.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { PostsComponent } from './modules/posts/posts.component';
import { ProjectsComponent } from './modules/projects/projects.component';
import { AuthComponent } from './auth/auth.component';
import { AuthGuardService } from './services/auth-guard.service';
import { ProjectDetailsComponent } from './modules/projects/project-details/project-details.component';



const routes: Routes = [
  { path: "", component: HomeComponent, canActivate: [AuthGuardService] },
  { path: "home", component: HomeComponent, canActivate: [AuthGuardService]},
  {
    path: "auth", component: AuthComponent, children: [
      { path: "login", component: LoginComponent },
      { path: "resetPwd", component: ResetPwdComponent },

      {
        path: "reset", children: [
          {
            path: "**", component: SubmitPwdComponent
          }
        ]
      }
    ]
  },
  {
    path: 'dashboard', component:DefaultComponent,
children:[{
  path: '',
  component:DashboardComponent
},{
  path:'posts',//employees
  component:PostsComponent
},{
  path:'projects',
  component:ProjectsComponent,children:[
    {path:":id",component:ProjectDetailsComponent}
  ]
      }], canActivate: [AuthGuardService]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
