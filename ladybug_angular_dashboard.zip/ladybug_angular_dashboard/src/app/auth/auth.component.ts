import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  user:Employee;

  constructor(private svc: AuthService) { }

  ngOnInit() {
    console.log(sessionStorage.getItem("user"));
    if(sessionStorage.getItem("user") == null || sessionStorage.getItem("user") == undefined){
      sessionStorage.setItem("user","");
    }
  }



}
