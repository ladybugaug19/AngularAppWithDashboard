import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Directive } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/layout/navbar/navbar.component';
import { HomeComponent } from './components/layout/home/home.component';
import { LoginComponent } from './auth/login/login.component';
import { AuthService } from './services/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { ResetPwdComponent } from './auth/reset-pwd/reset-pwd.component';
import { SubmitPwdComponent } from './auth/submit-pwd/submit-pwd.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DefaultModule } from './layouts/default/default.module';
import { AuthComponent } from './auth/auth.component';
import { ProjectDetailsComponent } from './modules/projects/project-details/project-details.component';
import { BugsComponent } from './modules/bugs/bugs.component';
import { BugCreateComponent } from './modules/bugs/bug-create/bug-create.component';
import { EmployeeService } from './services/employee.service';
import { ProjectService } from './services/project.service';
import { BugViewComponent } from './modules/bugs/bug-view/bug-view.component';
import { BugEditComponent } from './modules/bugs/bug-edit/bug-edit.component';
import {
  MatSidenavModule,
  MatDividerModule,
  MatCardModule,
  MatPaginatorModule,
  MatTableModule,
  MatSortModule,
  MatButtonModule
} from "@angular/material";
import { MatToolbarModule } from '@angular/material/toolbar';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    LoginComponent,
    ResetPwdComponent,
    SubmitPwdComponent,
    AuthComponent,
    ProjectDetailsComponent,
    BugsComponent,
    BugCreateComponent,
    BugViewComponent,
    BugEditComponent,
    
    
    
  ],
  imports: [
    BrowserModule, 
    AppRoutingModule, 
    FormsModule, 
    HttpClientModule,
    BrowserAnimationsModule,
    DefaultModule,
    MatSidenavModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatToolbarModule,
    MatButtonModule
  ],
  providers: [AuthService,EmployeeService,ProjectService],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
