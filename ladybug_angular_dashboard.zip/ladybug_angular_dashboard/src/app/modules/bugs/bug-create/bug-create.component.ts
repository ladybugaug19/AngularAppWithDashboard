import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-bug-create',
  templateUrl: './bug-create.component.html',
  styleUrls: ['./bug-create.component.css']
})
export class BugCreateComponent implements OnInit {

  mgrName:string;
  empName:string;
  constructor(private empSvc:EmployeeService) { }

  ngOnInit() {
    let userDtls = JSON.parse(localStorage.getItem("user"));
    let mgrId:number = userDtls.empMgr.empId;
    this.empSvc.getEmpById(mgrId).subscribe(emp=>{
      this.mgrName = emp.firstName+" "+emp.lastName;
    });
    this.empName = userDtls.firstName+" "+userDtls.lastName;
  }

}
