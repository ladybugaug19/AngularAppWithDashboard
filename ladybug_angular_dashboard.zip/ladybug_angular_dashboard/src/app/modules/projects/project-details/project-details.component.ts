import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ProjectService } from 'src/app/services/project.service';
import { Project } from 'src/app/models/project.model';
import { BugDtls } from 'src/app/models/bug-dtls.model';


@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {

  project: Project;
  bugs: BugDtls[];
  empMgr:string;
  empRole:string;

  constructor(private svc: ProjectService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    const id = +this.route.snapshot.params['id'];
    this.empRole = JSON.parse(localStorage.getItem("user")).login.role;
    console.log(this.empRole);
    console.log(id);
    this.svc.getSingleProject(id).subscribe(p=>{
      this.project = p;
      console.log(this.project);
      this.bugs = p.bugDtls;
    });
    

    // if(localStorage.getItem("user") != null && localStorage.getItem("user") != undefined && localStorage.getItem("user") != "" && localStorage.getItem("user") )
    // this.empMgr = localStorage.getItem("user");
  }

}
