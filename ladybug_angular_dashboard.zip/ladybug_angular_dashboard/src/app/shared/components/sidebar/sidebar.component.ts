import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  userName:string;
  role:string;

  constructor() { }

  ngOnInit() {
    if(localStorage.getItem("user") != null){
      this.userName = JSON.parse(localStorage.getItem("user")).firstName;
    }
  }

  getUserRole(){
    this.role= JSON.parse(localStorage.getItem("user")).login.role;
    if(this.role=='DEVTEST'){
      return "Product Engineer";
    }
    else
      return this.role;

  }

}
