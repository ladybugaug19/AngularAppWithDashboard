import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DefaultComponent } from "./default.component";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "../shared.module";
import {
  MatSidenavModule,
  MatDividerModule,
  MatCardModule,
  MatPaginatorModule,
  MatTableModule,
  MatSortModule,
  MatGridListModule,
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
} from "@angular/material";
import { MatToolbarModule } from '@angular/material/toolbar';
import { DashboardComponent } from "src/app/modules/dashboard/dashboard.component";
import { ProjectsComponent } from "src/app/modules/projects/projects.component";
import { EmployeesComponent } from "src/app/modules/employees/employees.component";
import { ProjectDetailsComponent } from 'src/app/modules/projects/project-details/project-details.component';

@NgModule({
  declarations: [
    DefaultComponent,
    DashboardComponent,
    ProjectsComponent,
    EmployeesComponent,
    ProjectDetailsComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    RouterModule,
    SharedModule,
    MatSidenavModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatToolbarModule,
    MatGridListModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
  ]
})
export class DefaultModule {}
