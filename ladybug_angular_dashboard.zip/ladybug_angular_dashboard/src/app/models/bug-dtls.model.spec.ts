import { BugDtls } from './bug-dtls.model';

describe('BugDtls', () => {
  it('should create an instance', () => {
    expect(new BugDtls()).toBeTruthy();
  });
});
